# Search trees

## Creating a search within a BST

## Instructions 
Within a BST (Binary Search Tree) constructor, create a function that takes an argument of a value, and searches the binary search tree for that value. If it finds that value, the function should return the entire node. If it doesn't, it should return null.

In prompt.js, you are given a BST constructor, a node constructor, some tests, and finally an empty search function.

In Hint, you are given everything that is given in prompt in addition to some pseudocode. 