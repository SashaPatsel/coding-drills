// YOUR WORK HERE




// TESTS
console.log(fib(7))
console.log(fib(0))

console.log(fib1(7))
console.log(fib1(0))