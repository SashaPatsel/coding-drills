# Algos N.5

## Largest sum

Given an array of numbers, create a function which returns the largest sum of any of the two numbers in that array.