# Algos N.6

## Find the longest word in a sentence

In this exercise, you are given a function that takes a sentence (in the form of a string) as an argument.

Your function should return the longest word in that sentence.

Note that this activity also contains a bonus. Proceed to prompt.html to complete the activity and see the bonus

### Example
The sentence "It is our choices, that show what we truly are, far more than our abilities" should return the word "abilities", because it is longer than any other word in the sentence.