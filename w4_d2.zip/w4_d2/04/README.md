# Algos N.5

## Largest sum

Given an array of numbers, create a function which returns the largest sum of any of the two numbers in that array.

### Example
Imagine you are given the following array :

[13, 22, 4, 18, 51, 8, 12, 36]

Your function should return 87, because 87 is the sum of 51 and 36, the two largest values in this array. 