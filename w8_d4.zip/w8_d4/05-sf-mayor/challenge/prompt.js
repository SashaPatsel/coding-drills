// You asked for the challenge...

var input = [ 
  [3, 0, 8, 4], 
  [2, 4, 5, 7],
  [9, 2, 6, 3],
  [0, 3, 1, 0] 
]

var input2 = [ 
  [23, 55, 28, 14], 
  [12, 64, 55, 67],
  [65, 32, 26, 53],
  [70, 36, 61, 80] 
]


function skyline(arr) {

}


console.log(skyline(input)) //35
console.log(skyline(input2)) // 268