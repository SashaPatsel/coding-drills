# Algos

## Where'd they go???

## Instructions
Given an array of integers, find the missing numbers. 

Imagine we sorted this array and wanted to count through the numbers consecutively (1,2,3,4) etc...

return an array of the numbers that break the consectuvive rythmn of this list. 

## Example

If we were given [9,4,3,6,8,2], we would return [5,7].

As given the array in sorted form would read [2,3,4,6,8,9].

The numbers 5 and 7 would make it a complete list.

