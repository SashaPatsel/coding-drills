// Complete your work in the function below.

function spiralist(n) {

}

console.log(0, spiralist(0))

console.log(1, spiralist(1))

console.log(2, spiralist(2))

console.log(3, spiralist(3))

console.log(9, spiralist(9))