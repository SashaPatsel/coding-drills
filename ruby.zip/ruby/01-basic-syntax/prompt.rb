# 1. Create you store's profile using a hash. You must include at least 4 different keys, and one of those keys must point to an array of items your store sells.


# 2. Print out a short bio about your store using some of the keys in the hash you just created.


# 3. Print all the items your store sells.


# 4. Add 5 new items to your warehouse and print out your updated stores.

# 5. Remove three items from your warehourse and print out your updated stores.


