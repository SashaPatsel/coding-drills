
def print_stairs()
# YOUR WORK HERE
  
end


# Tests
print_stairs(0)
print_stairs(1)
print_stairs(2)
print_stairs(3)
print_stairs(7)
print_stairs(10)