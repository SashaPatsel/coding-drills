var Node = function (data) {
  // The value in the node
  this.data = data
  // A pointer to all this node's children
  this.children = []
}

// YOUR WORK HERE

