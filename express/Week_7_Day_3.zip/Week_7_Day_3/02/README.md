# MYSQL PRACTICE - joins #

### MYSQL Fundamentals: inner joins ###

## Instructions 
- `Install packages`
- `config db`

`explain the table was created in the last exercise`
`Elaborate on this`
- Create the query to inner join the sql table on nutrition(id) and ingredients(foodname)



## Example
- https://www.w3schools.com/sql/sql_join_inner.asp

![results](./gif/results.gif)