# MYSQL PRACTICE - joins #

### MYSQL Fundamentals Practice of right join ###

## Instructions 
- `Install packages`
- `config db`

`Elaborate on this` 
- Create the query that right joins the sql table of ingridents on the nutrition of protein, fats and calories

## Example

- A link to right join https://www.w3schools.com/sql/sql_join_right.asp

![results](./gif/results.gif)


