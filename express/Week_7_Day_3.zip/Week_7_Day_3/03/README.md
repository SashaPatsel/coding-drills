# MYSQL PRACTICE - joins #

### MYSQL Fundamentals Practice of inner joins ###

## Instructions 
- `Install packages`
- `config db`

`Elaborate on this` 
- Create the query that left joins the sql table of nutrition on the ingredients of seasoning, oils, side_dish and the origin

## Example
- A link to left join https://www.w3schools.com/sql/sql_join_left.asp

![results](./gif/results.gif)