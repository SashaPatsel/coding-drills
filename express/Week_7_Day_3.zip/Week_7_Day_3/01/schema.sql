DROP DATABASE IF EXISTS food_DB;
CREATE database food_DB;

USE food_DB;
-- create a foods_nutrition table that contains id, foodname, calories, protein, fats, carbohyrates and primary key of id 
CREATE TABLE foods_nutrition (
  -- Code Starts Here









  -- Code Ends Here
);

SELECT * FROM foods_nutrition;

-- create a food_ingredients table that contains id, foodname main_ingredients, seasoning, oils, side_dish, origin and primary key of id
CREATE TABLE food_ingredients (
  -- Code Starts Here


  







  -- Code Ends Here
);

SELECT * FROM food_ingredients;