# MYSQL PRACTICE - Import Wizard and Schemas #


### MYSQL Fundamentals: Building schemas using csv files ###

`Put these in context. What do they mean here?`
Primary Key, Name, calories, fats, carbohyrates, protein

- In this code drill, we are building a database of foods and their nutitional value nutrition.

1. Following the instructions in schema.sql, populate two tables:
- foods_nutrition
- foods_ingredients

2. Using the import wizard, `give instructions on how to do this`, `Tell them what to do with the import wizard`


## Example
![food](./images/foodNutrition.gif)
