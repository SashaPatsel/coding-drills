-- Database: restaurantsDB

-- Table: restaurants

-- Data: id(auto-incrementing), name, link, image, rating  
