# ES6

## Algo-conversion

## Instructions

In prompt.js, you are given a few algorithms that are written with ES5 syntax. Your job is to convert them to ES6 syntax within the designated areas.

There are tests written for the given functions, as well as for your own. Name your function the same as the given one, but without the "1" at the end.
