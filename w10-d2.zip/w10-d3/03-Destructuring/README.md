# ES6

## Destructuring

## Instructions

In this exercise, you will be tested on your ability to destructure both arrays and objects. Each ask in prompt.js will be working with the same object given to you at the top of the file.

Follow the instructions in each ask, and write your code in the designated areas.
