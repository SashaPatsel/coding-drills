# ES6

## Old alg, new syntax

## Instructions
In this exercise, you will be asked to create a bubblesorting algorithm. The bubblesort algorithm takes an unsorted array as an argument, and returns that same array, but sorted.

Bubblesort looks to see if a number is greater than the one following it. If it is, they swap places. When this process is repeated, the largest numbers "bubble" to the top.

You will be asked to solve this function in ES6 syntax. You must also use the forEach method at least once.

Proceed to prompt.js