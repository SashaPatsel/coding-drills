# ES6 

## ES6 Challenges

## Instructions

Navgivate to prompt.js where you will see a series of unique challenges. Each has its own set of instructions, designated work areas and tests.