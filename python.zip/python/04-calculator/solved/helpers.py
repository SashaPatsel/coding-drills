def add_nums(num1, num2):
  return int(num1) + int(num2)

def subtract_nums(num1, num2):
  return int(num1) - int(num2)

def multiply_nums(num1, num2):
  return int(num1) * int(num2)

def divide_nums(num1, num2):
  return int(num1)/int(num2)

