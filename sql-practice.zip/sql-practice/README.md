# So you think you can SQL?!?!

## Conduct CRUD operations in SQL with Node

## Prompt
The all time Emmy's award show is having it's grand opening! 

Crisis has struck the new Emmy's show as pricewaterhousecoopers has already lost the data for all the nominees. 

Only YOU are qualified enough to make a new database for them before the show. The emmys are asking A LOT though... They want you to be able to Create, Read, Update and even Delete nominees. Oh CRUD!
 
## Instructions

1. Attemp to complete `unsolved-harder`. If you find it too challenging, take a shot at `unsolved-easier`.
2. Open schema.sql (in whichever folder you choose) for more instructions 🕵️‍. Follow the Instructions there.
3. Go to index.js and follow the instructions laid out there 🕵.
You'll notice that there are instructions numbered out there. Make sure you catch all the instructions. Check that you didn't skip any numbers
4. You're hired!!!
