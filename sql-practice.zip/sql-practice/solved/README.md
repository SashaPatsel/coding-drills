So you think you can SQL?!?!

The all time Emmy's award show is having it's grand opening! 

Crisis has struck the new Emmy's show as pricewaterhousecoopers has already lost the data for all the nominees. 

Only YOU are qualified enough to make a new database for them before the show. The emmys are asking A LOT though... They want you to be able to Create, Read, Update and even Delete nominees. Oh CRUD!
 

Step 1. Open schema.sql for more instructions 🕵️‍
