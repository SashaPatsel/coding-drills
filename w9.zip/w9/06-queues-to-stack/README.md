# Computer Science

## Makin' Stacks out of Queues 🤯🤯

## Instructions
Make a stack out of two queues. In prompt.js, you are given a constructor that mimicks the behavior of a queue and nothing else. In hint/hint.js, you are given the aforementioned constructor in additon to the skeleton of the stack, as well as some hints.

Create a new stack constructor with the same three methods as the one we made in 02:

- add
- remove
- peek

You can only use the methods of the queue constructor to manipulate your data. Do not use any other data structures for this activity.