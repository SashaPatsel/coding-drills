# Computer Science

## Makin' Queues out of Stacks 🤯

## Instructions
Make a queue out of two stacks. You are given a constructor that mimicks the behavior of a stack and nothing else. 

Create a new queue constructor with the same three methods as the one we made in 02:

- add
- remove
- peek

You can only use the methods of the stack constructor to manipulate your data. Do not use any other data structures for this activity.