# Efficiency

## Big O

## Instructions

In prompt.js, you'll find five sets of two algorithms. Each set is a prompt you've seen in past code drills. 

You'll find two, equally valid solutions to each problem.

In a section below the algorithms, you'll be prompted to enter the time complexity (in Big O), as well as which (if either) is more efficient.

Proceed to prompt.js to proceed.