# Algos 

## Add digits

## Instructions

Given a number, add all of its digits. Continue to do so until the sum is one digit. Return the single digit.

## Example 
Given the number 644, your function should return 5. 6 + 4 + 4 = 14. 1 + 4 = 5.

Given the number 42, your function should return 6. 4 + 2 = 6. 

Given the number 89657, your function should return 8. 8 + 9 + 6 + 5 + 7 = 35. 3 + 5 = 8.