# Algos 

## Chunkify

## Instructions

Given An array and a number, return an array containing several sub arrays, each the size of the given number.

## Example

Given [5,2,6,7,8,9,4,6,8] and 4, you should return [[5,2,6,7], [8,9,4,6], [8]]

Given [2,4,7,3,1,7,9,4,8,0,4,7,9,3,5,5,6,3,2,2,2,2,1] and 3, you should return [[2,4,7], [3,1,7], [9,4,8], [0,4,7], [9,3,5], [5,6,3], [2,2,2], [2,1]]

Given [1,2,3,4] and 2, you should return [[1,2], [3,4]]