# Algos

## Steps Pt.2: The Pyramid

Given a number create a pyramid containing the same number of layers as the given number. So given the number 8, your pyramind should be 8 layers high. Your pyramid will be made out of `#`s and ` `s.

# Example
Given 3, you should console.log:
"  #  "
" ### "
"#####"

Given 4, you should console.log:
"   #   "
"  ###  "
" ##### "
"#######"

Given 8, you should console.log:
"         #         "
"        ###        "
"       #####       "
"      #######      "
"     #########     "
"    ###########    "
"   #############   "
"  ###############  "
