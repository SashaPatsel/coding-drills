# Solution

The key to this problem is to isolate each iteration of the counting. When you break it down, you notice that each cycle is comprised of 8 numbers. When we hit 9, we know we're landing back on the thumb. 

Each cycle finishes on the index finger. We therefore know that multiples of 8 will all be the index finger. 

It just so happens that 1000 is a multiple of 8. As a result, the baby will finish on her index finger when she reaches 1000. 