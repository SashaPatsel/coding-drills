# Solution

_Let's refer to our three cantines of 8, 5 and 3 litres as cantines A, B, and C, respectively._

We can denote each cantine's current amount of water like so A(8), B(0), C(0)

The steps below represent how we will pour the water to ultimately get one cantine with exactly four litres. 

A(8) B(0) C(0) -> A(3) B(5) C(0) -> A(3) B(2) C(3) -> A(6) B(2) C(0) -> A(1) B(5) C(2) -> A(1) B(4) C(3)

