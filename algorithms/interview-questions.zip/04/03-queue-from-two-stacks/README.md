# Computer Science

## Making Stacks out of Queues

## Instructions

Create a stack using only queus

Assume you are given a queue with the the following methods:

- add
- remove
- peek

Create a new stack with the same three methods using only the given queue

- add
- remove
- peek

You can only use the methods of the queue constructor to manipulate your data. Do not use any other data structures for this activity.

## Optimal Time
O(n^2)