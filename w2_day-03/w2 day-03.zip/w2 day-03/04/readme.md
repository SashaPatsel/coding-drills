# Using Bracket Notation

# Populate an object without hard-coding values into it

In this exercise, you are given two objects. They are actually the same object, except that one contains content, and the other doesn't. Your job will be to convert the object without content into an exact replica of the object that is commented out.

You may not create a new object, but can instead only use bracket notation to populate the empty sanFran object.

You will know you have completed the challenge when the given console log matches the commented out object.