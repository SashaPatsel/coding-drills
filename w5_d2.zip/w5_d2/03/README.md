# Algos N.3

## What's so special about this sentence anyway???

## Instructions
Given two sentences (as strings), return an array containing all the words that appear only once across both strings.


## Example
Given the strings "Sasha is very nice" and "Robert is very kind", your function should return ["Sasha", "Robert, "nice", "kind"].

However if the sentences were "Sasha is very nice nice" and "Robert is very kind". The return would be ["Sasha", "Robert, "kind"] because "nice" is repeated.

Each of the words in the above array appear only once in either of the two sentences.
