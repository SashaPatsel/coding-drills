# Algos N.2

## All candies taste the same

## Instructions
We are making an algorithm for people who have no idea how to tell different candies apart.
 
Our algorithm will tell us how many of our candies are sourpatches.

Given two different strings, create a function which returns the number of instances a character from the first string is found in the second string. (AKA, how many of my candies are sourpatches?)

## Example
Given "abcd" and "ogcbwbkdafjdcjddd", your function should return the number 10. 10 is the number of times any of the characters in the first string is found in the second string.

Note that we are not interested in how many times a given character from the first string is found. We don't need to know that there are 5 ds or 1 a for example. Just return the sum of all those values. 