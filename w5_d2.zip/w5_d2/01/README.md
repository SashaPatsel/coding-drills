# Algos N.1

## Help us cross the bridge!!!

## Prompt
It's late. Very late. Sasha, Jerome, Ricky and Robert are looking down a dark, scary bridge. There is no help in sight. 

The group has only one flashlight among them. What's worse, the bridge looks pretty broken down and can definitely not support any more than two people at a time.

If any of them cross the bridge without the flashlight, they'll surely fall through one of the steps 😧. That means no matter what, a flashlight must be present when one or two people cross the bridge.

The foursome find themselves in varying degrees of physical shape:

- Jerome can cross the bridge in 1 minute. 
- Ricky can cross in 2 minutes. 
- Robert can cross in 5 minutes
- Sasha, who clearly should go to the gym more, takes 10 minutes to cross.

Because of the flashlight, if two people cross the bridge together, they can only go as fast as the slower of the two.


## Instructions
Class is starting soon! Sasha, Jerome, Ricky and Robert need to all make it across the bridge in 17 minutes or less or they'll be late!

Help them all get across in time!!!

Try and break this problem down into steps. It may be helpful to sketch out the problem. 

Create a solved.md and write down your solution there. 