# Solution

- Jerome and ricky cross (2 mins)
- Jerome returns with the flashlight. (1 min)
- Robert and Sasha cross (10 mins)
- Ricky returns with the flashlight (2 mins)
- Jerome and Ricky cross again (2 mins)

2 + 1 + 10 + 2 + 2 = 17