import React, { Component } from 'react';
import './App.css';

import Landing from "./pages/Landing/Landing"

class App extends Component {
  render() {
    return (
      <Landing/>
    );
  }
}

export default App;
